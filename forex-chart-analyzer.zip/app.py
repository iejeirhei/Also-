
from flask import Flask, request, jsonify
from PIL import Image
import base64
import openai
import io

app = Flask(__name__)
openai.api_key = 'your-openai-api-key-here'

@app.route('/analyze', methods=['POST'])
def analyze():
    if 'image' not in request.files:
        return jsonify({'error': 'No image uploaded'}), 400

    image_file = request.files['image']
    img_bytes = image_file.read()
    img_base64 = base64.b64encode(img_bytes).decode()

    prompt = f"""
    Analyze this Forex chart (Base64-encoded image). Identify if it's a Buy or Sell opportunity. 
    Provide:
    - Entry suggestion
    - Stop loss
    - 2 take profit levels
    - Risk-to-reward ratio
    - Short reasoning.

    Image (Base64): {img_base64[:200]}... (truncated)
    """

    response = openai.ChatCompletion.create(
        model="gpt-4-vision-preview",
        messages=[{"role": "user", "content": [{"type": "text", "text": prompt},
                                                {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{img_base64}"}}]}],
        max_tokens=800
    )

    content = response['choices'][0]['message']['content']
    return jsonify({'analysis': content})

if __name__ == '__main__':
    app.run(debug=True)
